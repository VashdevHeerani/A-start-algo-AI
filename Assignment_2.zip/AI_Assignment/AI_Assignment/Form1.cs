﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AI_Assignment.Algo;

namespace AI_Assignment
{
    
    public partial class Form1 : Form
    {
        private Graphics g1;
        private int num;
        private int sizeGrid;
        private int numSG;
        private byte[,] gird;
        private Point start;
        private Point end;
        private bool[,] noPath;


        public Form1(int index,int index2)
        {
            InitializeComponent();
            num = 10; 
            sizeGrid = 50;
            numSG = 0;
            switch (index)
            {
                case 0:
                    num = 10;
                    sizeGrid = 50;
                    break;
                case 1:
                    num = 20;
                    sizeGrid = 25;
                    break;
                case 2:
                    num = 30;
                    sizeGrid = 16;
                    break;
                case 3:
                    num = 40;
                    sizeGrid = 12;
                    break;
                case 4:
                    num = 50;
                    sizeGrid = 10;
                    break;
                case 5:
                    num = 60;
                    sizeGrid = 8;
                    break;
                case 6:
                    num = 70;
                    sizeGrid = 7;
                    break;
                case 7:
                    num = 80;
                    sizeGrid = 6;
                    break;
                case 8:
                    num = 90;
                    sizeGrid = 5;
                    break;
                case 9:
                    num = 100;
                    sizeGrid = 5;
                    break;

            }
            gird = new byte[num, num];
            noPath=new bool[num,num];
            int hurdle = 0;
            int percentage = 0;
            switch (index2)
            {
                case 0:
                    percentage = 10;
                    break;
                case 1:
                    percentage = 25;
                    break;
                case 2:
                    percentage = 50;
                    break;
                case 3:
                    percentage = 75;
                    break;
            }
            hurdle = ((num*num)*percentage) / 100;

            Random rand=new Random();

            pictureBox1.Image = new Bitmap(500, 500);
            g1 = Graphics.FromImage(this.pictureBox1.Image);
            Pen gridPen = new Pen(Color.Black, 2);
            for (int i = 0; i < num; i++)
            {
                for (int j = 0; j < num; j++)
                {
                    g1.DrawRectangle(gridPen, i * sizeGrid, j * sizeGrid, sizeGrid, sizeGrid);
                    gird[i, j] = (byte)sizeGrid;
                    noPath[i, j] = false;
                }
            }
            int x = 0;
            int y = 0;
            Brush b1 = new System.Drawing.SolidBrush(System.Drawing.Color.Purple);
            while (hurdle > 0)
            {
                x = rand.Next(num);
                y = rand.Next(num);
                g1.FillRectangle(b1, x * sizeGrid, y * sizeGrid, sizeGrid, sizeGrid);
                noPath[x, y] = true;
                hurdle--;
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            if (numSG < 2)
            {
                MouseEventArgs me = (MouseEventArgs)e;
                int x = me.X / sizeGrid;
                int y = me.Y / sizeGrid;
                this.pictureBox1.Image = new Bitmap(this.pictureBox1.Image);
                g1 = Graphics.FromImage(this.pictureBox1.Image);
                Brush b1 = new System.Drawing.SolidBrush(System.Drawing.Color.Green);
                if (numSG == 0 && !noPath[x,y])
                {
                    b1 = new System.Drawing.SolidBrush(System.Drawing.Color.Green);
                    start = new Point(x, y);
                    numSG++;
                    g1.FillRectangle(b1, x * sizeGrid, y * sizeGrid, sizeGrid, sizeGrid);
                }
                else if(!noPath[x,y])
                {
                    b1 = new System.Drawing.SolidBrush(System.Drawing.Color.Red);
                    end = new Point(x, y);
                    numSG++;
                    g1.FillRectangle(b1, x * sizeGrid, y * sizeGrid, sizeGrid, sizeGrid);
                }
               
                
            }
 
        }

        private void btn_run_Click(object sender, EventArgs e)
        {
            PathFinder p=new PathFinder(gird,noPath);
            List<PathFinderNode> path = p.FindPath(start,end);
            if (path == null)
            {
                MessageBox.Show("Path not found");
            }
            else
            {
                this.pictureBox1.Image = new Bitmap(this.pictureBox1.Image);
                g1 = Graphics.FromImage(this.pictureBox1.Image);
                Brush b1 = new System.Drawing.SolidBrush(System.Drawing.Color.Black);
                foreach (PathFinderNode pa in path)
                {
                    g1.FillRectangle(b1, pa.x * sizeGrid, pa.y * sizeGrid, sizeGrid, sizeGrid);
                }
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            DataForm f = new DataForm();
            this.Hide();
            f.Show();
           
        }


    }
}
